﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ZeeMoviesController : Controller
    {

        [HttpGet("GetAllDetails")]
        public IActionResult GetUserDetails()
        {
            string path = "MoviesData.json";
            string json;
            using (StreamReader r = new StreamReader(path))
            {
                json = r.ReadToEnd();
            }

            JObject a = JObject.Parse(json);
            if (a != null)
            {
                JArray c = (JArray)a["movie"];
                IList<Movie> person = c.ToObject<IList<Movie>>();
                return Ok(person);
            }
            return Ok();
        }

        [HttpPost("AddMovie")]
        public IActionResult Add(Movie movie)
        {
            string path = "MoviesData.json";
            string json;
            using (StreamReader r = new StreamReader(path))
            {
                json = r.ReadToEnd();
            }
            JObject jsonObj = JObject.Parse(json);
            var newCompanyMember = "{ 'Title': '" + movie.Title + "', 'US_Gross': '" + movie.US_Gross + "', 'Worldwide_Gross': '" + movie.Worldwide_Gross + "'" +
                ", 'US_DVD_Sales': '" + movie.US_DVD_Sales + "', 'Production_Budget': '" + movie.Production_Budget + "', 'Release_Date': '" + movie.Release_Date + "'" +
                ", 'MPAA_Rating': '" + movie.MPAA_Rating + "', 'Running_Time_min': '" + movie.Running_Time_min + "', 'Distributor': '" + movie.Distributor + "'" +
                ", 'Source': '" + movie.Source + "', 'Major_Genre': '" + movie.Major_Genre + "', 'Creative_Type': '" + movie.Creative_Type + "'" +
                ", 'Director': '" + movie.Director + "', 'Rotten_Tomatoes_Rating': '" + movie.Rotten_Tomatoes_Rating + "', 'IMDB_Rating': '" + movie.IMDB_Rating + "', 'IMDB_Votes': '" + movie.IMDB_Votes + "'    }";

            var experienceArrary = jsonObj.GetValue("movie") as JArray;
            JObject newCompany = JObject.Parse(newCompanyMember);
            experienceArrary.Add(newCompany);

            jsonObj["movie"] = experienceArrary;
            string newJsonResult = JsonConvert.SerializeObject(jsonObj,
                                   Formatting.Indented);

            using (var fs = new FileStream(path, FileMode.Truncate))
            {
                fs.Close();
            }

            using (var tw = new StreamWriter(path, true))
            {
                tw.WriteLine();
                tw.WriteLine(newJsonResult);
                tw.Close();
            }

            JArray c = (JArray)jsonObj["movie"];
            IList<Movie> person = c.ToObject<IList<Movie>>();
            return Ok(new { Success = "Created successfully" });
        }


        [HttpPost("UpdateMovie")]
        public IActionResult Update(Movie movie)
        {
            string path = "MoviesData.json";
            string json;
            using (StreamReader r = new StreamReader(path))
            {
                json = r.ReadToEnd();
            }
            JObject jsonObj = JObject.Parse(json);
            JArray experiencesArrary = (JArray)jsonObj["movie"];


            IList<Movie> per = experiencesArrary.ToObject<IList<Movie>>();
            int count = per.Where(c => c.Title == movie.Title).Count();


            if (count == 1)
            {
                foreach (var company in experiencesArrary.Where(obj => obj["Title"].Value<string>() == movie.Title))
                {
                    company["US_Gross"] = !string.IsNullOrEmpty(movie.US_Gross) ? movie.US_Gross : company["US_Gross"].ToString();
                    company["Worldwide_Gross"] = !string.IsNullOrEmpty(movie.Worldwide_Gross) ? movie.Worldwide_Gross : company["Worldwide_Gross"].ToString();
                    company["US_DVD_Sales"] = !string.IsNullOrEmpty(movie.US_DVD_Sales) ? movie.US_DVD_Sales : company["US_DVD_Sales"].ToString();
                    company["Production_Budget"] = !string.IsNullOrEmpty(movie.Production_Budget) ? movie.Production_Budget : company["Production_Budget"].ToString();
                    company["Release_Date"] = !string.IsNullOrEmpty(movie.Release_Date) ? movie.Release_Date : company["Release_Date"];
                    company["MPAA_Rating"] = !string.IsNullOrEmpty(movie.MPAA_Rating) ? movie.MPAA_Rating : company["MPAA_Rating"].ToString();
                    company["Running_Time_min"] = !string.IsNullOrEmpty(movie.Running_Time_min) ? movie.Running_Time_min : company["Running_Time_min"].ToString();
                    company["Distributor"] = !string.IsNullOrEmpty(movie.Distributor) ? movie.Distributor : company["Distributor"].ToString();
                    company["Source"] = !string.IsNullOrEmpty(movie.Source) ? movie.Source : company["Source"].ToString();
                    company["Major_Genre"] = !string.IsNullOrEmpty(movie.Major_Genre) ? movie.Major_Genre : company["Major_Genre"];
                    company["Creative_Type"] = !string.IsNullOrEmpty(movie.Creative_Type) ? movie.Creative_Type : company["Creative_Type"].ToString();
                    company["Director"] = !string.IsNullOrEmpty(movie.Director) ? movie.Director : company["Director"].ToString();
                    company["Rotten_Tomatoes_Rating"] = !string.IsNullOrEmpty(movie.Rotten_Tomatoes_Rating) ? movie.Rotten_Tomatoes_Rating : company["Rotten_Tomatoes_Rating"].ToString();
                    company["IMDB_Rating"] = !string.IsNullOrEmpty(movie.IMDB_Rating) ? movie.IMDB_Rating : company["IMDB_Rating"].ToString();
                    company["IMDB_Votes"] = !string.IsNullOrEmpty(movie.IMDB_Votes) ? movie.IMDB_Votes : company["IMDB_Votes"].ToString();
                }

                jsonObj["movie"] = experiencesArrary;
                string output = Newtonsoft.Json.JsonConvert.SerializeObject(jsonObj, Newtonsoft.Json.Formatting.Indented);

                using (var fs = new FileStream(path, FileMode.Truncate))
                {
                    fs.Close();
                }

                using (var tw = new StreamWriter(path, true))
                {
                    tw.WriteLine(output);
                    tw.Close();
                }
                JArray c = (JArray)jsonObj["movie"];
                IList<Movie> person = c.ToObject<IList<Movie>>();
                return Ok(new { Success = "Updated successfully" });
            }
            else if (count > 1)
            {
                return Ok(new { error = "Title is not unique" });
            }
            else
            {
                return Ok("Not found");
            }
        }


        [HttpPost("DeleteMovie")]
        public IActionResult Delete(Movie movie)
        {
            var newCompanyMember = "{ 'Title': '" + movie.Title + "'}";

            string path = "MoviesData.json";
            string json;
            using (StreamReader r = new StreamReader(path))
            {
                json = r.ReadToEnd();
            }

            JObject jObject = JObject.Parse(json);
            JArray experiencesArrary = (JArray)jObject["movie"];

            if (movie.Title != null)
            {
                var companyName = string.Empty;
                var companyToDeleted = experiencesArrary.FirstOrDefault(obj => obj["Title"].Value<string>() == movie.Title);

                experiencesArrary.Remove(companyToDeleted);

                string output = Newtonsoft.Json.JsonConvert.SerializeObject(jObject, Newtonsoft.Json.Formatting.Indented);
                using (var fs = new FileStream(path, FileMode.Truncate))
                {
                    fs.Close();
                }

                using (var tw = new StreamWriter(path, true))
                {

                    tw.WriteLine(output);
                    tw.Close();
                }
                JArray c = (JArray)jObject["movie"];
                IList<Movie> person = c.ToObject<IList<Movie>>();
                return Ok(new { Success = "Deleted successfully" });
            }
            else
            {
                Console.Write("Invalid title!");
                return Ok();
            }
        }

        [HttpPost("GetMovieTitle")]
        public IActionResult GetMovieByTitle(Movie movie)
        {
            string path = "MoviesData.json";
            string json;
            using (StreamReader r = new StreamReader(path))
            {
                json = r.ReadToEnd();
            }

            JObject a = JObject.Parse(json);
            if (a != null)
            {
                JArray c = (JArray)a["movie"];
                IList<Movie> person = c.ToObject<IList<Movie>>();
                Movie employee1 = person.Where(x => x.Title == movie.Title).FirstOrDefault();
                if (employee1 != null)
                {
                    return Ok(new { data = employee1 });
                }
                else
                {
                    return Ok(new { data = "Movie not found" });
                }
            }
            return Ok();
        }


        [HttpGet("GetbyGenre")]
        public IActionResult GetMoviesByGenre()
        {
            string path = "MoviesData.json";
            string json;
            int g = 0;
            using (StreamReader r = new StreamReader(path))
            {
                json = r.ReadToEnd();
            }
            JObject a = JObject.Parse(json);
            if (a != null)
            {
                JArray c = (JArray)a["movie"];
                IList<Movie> person = c.ToObject<IList<Movie>>();

                var data = from z in person
                           group z by z.Major_Genre
                         into kd
                           orderby kd.Key
                           select new
                           {
                               genre = kd.Key,
                               details = kd,
                               count = kd.Count()
                           };

                Hashtable h = new Hashtable();
                foreach (var item in data)
                {
                    string genre = item.genre;
                    int NumberOfMovies = item.count;
                    h.Add( (genre != null ) ? genre : "null" , NumberOfMovies);
                }
                return Ok(h);
            }
            return Ok();
        }

        [HttpGet("GetbyYear")]
        public IActionResult GetMoviesByYear()
        {
            string path = "MoviesData.json";
            string json;
            using (StreamReader r = new StreamReader(path))
            {
                json = r.ReadToEnd();
            }
            JObject a = JObject.Parse(json);
            if (a != null)
            {
                JArray c = (JArray)a["movie"];
                IList<Movie> person = c.ToObject<IList<Movie>>();

                var data = from z in person
                           group z by z.Release_Date.Substring(Math.Max(0, z.Release_Date.Length - 4))
                into kd
                           orderby kd.Key
                           select new
                           {
                               genre = kd.Key,
                               details = kd,
                               count = kd.Count()
                           };

                Hashtable h = new Hashtable();
                foreach (var item in data)
                {
                    string year = item.genre;
                    int NumberOfMovies = item.count;
                    h.Add(string.IsNullOrEmpty(year) ? "null" : year, NumberOfMovies);
                }
                return Ok(h);
            }
            return Ok();
        }


    }
}
